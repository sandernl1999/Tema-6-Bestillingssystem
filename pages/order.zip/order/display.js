import React, { useEffect } from "react";
import fire from "../../config/firebase-config";
import { HeadView, Wrapper } from "../../components";
import styles from "./index.module.css";
import style from "../auth/index.module.css";

export async function getServerSideProps() {
  return {
    props: {
      ssr: true,
    },
  };
}

export default function Display() {
  const [orders, setOrders] = React.useState([]);
  console.log(orders);

  useEffect(() => {
    const db = fire.firestore();
    db.collection("orders").onSnapshot(function (querySnapshot) {
      const orders = [];
      querySnapshot.forEach((doc) =>
        orders.push({ ...doc.data(), id: doc.id })
      );
      // Sortere ordere med orderDateTime
      orders.sort((a, b) => b.orderDateTime - a.orderDateTime);
      setOrders(orders);
    });
  }, []);

  return (
    <Wrapper className={styles.displayContainer}>
      <HeadView title={"Børres burgers take-away Orders"} />
      <main className={style.innerContainer}>
        <div className={styles.formContainer}>
          <div className={styles.displayHeader}>Pick-up food</div>
          <div className={styles.displayOrdersHeader}>Orders</div>
          <div className={styles.tableHeader}>
            <div style={{ paddingLeft: 20, fontSize: 18, fontWeight: 500 }}>
              In the oven
            </div>
            <div style={{ paddingRight: 20, fontSize: 18, fontWeight: 500 }}>
              Ready
            </div>
          </div>
          <div className={styles.productsSelectedContainer}>
            {orders?.length > 0 && (
              <div className={styles.orderNoContainer}>
                <div>
                  {orders
                    ?.filter((order) => order.orderStatus === "Order received")
                    ?.map((order, index) => {
                      return (
                        <div key={index} className={styles.orderField}>
                          {order.orderRefNumber}{" "}
                        </div>
                      );
                    })}
                </div>
                <div>
                  {orders
                    ?.filter((order) => order.orderStatus === "Ready")
                    ?.map((order, index) => {
                      return (
                        <div key={index} className={styles.orderField}>
                          {order.orderRefNumber}{" "}
                        </div>
                      );
                    })}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </Wrapper>
  );
}
