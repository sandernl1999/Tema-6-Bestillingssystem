import React, { useEffect } from "react";
import fire from "../../config/firebase-config";
import { HeadView, Wrapper, Button } from "../../components";
import styles from "./index.module.css";
import style from "../auth/index.module.css";

export async function getServerSideProps() {
  return {
    props: {
      ssr: true,
    },
  };
}

export default function () {
  const [orders, setOrders] = React.useState([]);
  console.log(orders);

  useEffect(() => {
    const db = fire.firestore();
    db.collection("orders").onSnapshot((querySnapshot) => {
      let orders = [];
      querySnapshot.forEach((doc) =>
        orders.push({ ...doc.data(), id: doc.id })
      );
      // Sorter ordre - orderDateTime
      orders = orders.sort((a, b) => b.orderDateTime - a.orderDateTime);
      orders = orders.filter(
        (order) => order.orderStatus !== "Picked-up/finished"
      );
      setOrders(orders);
    });
  }, []);

  const updateOrderStatus = (status, docId) => {
    const db = fire.firestore();
    db.collection("orders")
      .doc(docId)
      .update({ orderStatus: status })
      .then((r) => console.log(r))
      .catch((e) => console.log(e));
  };

  return (
    <Wrapper>
      <HeadView title={"Burger Take Away order"} />
      <main className={style.innerContainer}>
        <div className={styles.kitchenFormContainer}>
          <div className={styles.Header}>Børres </div>
          <div className={styles.tableHeader}>
            <div className={styles.newOrderStatus}>New order</div>
            <div className={styles.newOrderStatus}>Status?</div>
          </div>
          <div className={styles.productsSelectedContainer}>
            {orders?.length > 0 && (
              <div>
                {orders.map((order, index) => {
                  console.log("order::", orders);
                  return (
                    <div
                      key={index}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        marginBottom: "10px",
                        borderBottom: "1px solid",
                        paddingBottom: 10,
                      }}
                    >
                      <div style={{ paddingLeft: 20, width: 400 }}>
                        <label style={{ fontSize: 23, fontWeight: 500 }}>
                          {order.title}
                        </label>
                        <span>
                          {/*{order?.addOns?.map((addon) =>*/}
                          {/*  addon.type === "Fries"*/}
                          {/*    ? " +1 Fries"*/}
                          {/*    : ` +1 ${addon.softdrinkSize} Softdrink`*/}
                          {/*)}*/}

                          {order?.addOns?.map((addon) =>
                            addon.type === "Fries"
                              ? `+${addon.quantity} Fries`
                              : ` +${addon.quantity} ${addon.size} ${addon.type}`
                          )}
                          {order.chicken && "+1 Chicken"}
                          {order.bacon && "+1 Bacon"}
                        </span>
                      </div>

                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        {order?.orderStatus === "Order received" ? (
                          <button
                            onClick={() => updateOrderStatus("Ready", order.id)}
                          >
                            Ready?
                          </button>
                        ) : (
                          // <Button
                          //   onClick={() => updateOrderStatus("Ready", order.id)}
                          //   title={"Ready?"}
                          //   className={styles.button}
                          // />
                          <button
                            style={{
                              backgroundColor: "green",
                              cursor: "default",
                            }}
                          >
                            Ready?
                          </button>
                          // <Button
                          //   // style={{
                          //   //   backgroundColor: "green",
                          //   //   cursor: "default",
                          //   // }}
                          //   // className={styles.button}
                          //   title={"Ready?"}
                          // />
                        )}
                        {order.orderStatus === "Ready" ? (
                          <button
                            onClick={() =>
                              updateOrderStatus("Picked-up/finished", order.id)
                            }
                          >
                            Picked up?
                          </button>
                        ) : order?.orderStatus === "Picked-up/finished" ? (
                          <button
                            style={{
                              backgroundColor: "green",
                              cursor: "default",
                            }}
                          >
                            Picked up?
                          </button>
                        ) : (
                          ""
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </main>
    </Wrapper>
  );
}
